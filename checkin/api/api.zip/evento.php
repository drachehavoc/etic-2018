{
	"id": <?php echo $_GET['id'] ?>, 
	"nome": "evento <?php echo $_GET['id'] ?>", 
	"eticoin": 2
}