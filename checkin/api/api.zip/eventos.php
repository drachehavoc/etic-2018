[
	{"id": 1, "nome": "evento 1", "eticoin": 2},
	{"id": 2, "nome": "evento 1", "eticoin": 2},
	{"id": 3, "nome": "evento 1", "eticoin": 2},
	{"id": 4, "nome": "evento 1", "eticoin": 2},
	{"id": 5, "nome": "evento 1", "eticoin": 2},
	{"id": 6, "nome": "evento 1", "eticoin": 2}
]