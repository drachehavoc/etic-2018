<?php

echo random_int(0, 99);